Run this command in the terminal before the first run -> **pip install wordcloud nltk selenium**  

Blog Link - https://machinelearningprojects.net/youtube-comments-extraction-and-sentiment-analysis/
